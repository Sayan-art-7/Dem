using System.Windows;
namespace ObuvApp;
public partial class LoginWindow : Window
{
    public string UserRole { get; private set; } = "Гость";
    public LoginWindow() { InitializeComponent(); }
    private void Login_Click(object sender, RoutedEventArgs e)
    {
        string role = Database.Login(LoginBox.Text.Trim(), PasswordBox.Password);
        if (role == null) { MessageBox.Show("Неверный логин или пароль."); return; }
        UserRole = role; DialogResult = true;
    }
    private void Guest_Click(object sender, RoutedEventArgs e) { UserRole="Гость"; DialogResult=true; }
}
