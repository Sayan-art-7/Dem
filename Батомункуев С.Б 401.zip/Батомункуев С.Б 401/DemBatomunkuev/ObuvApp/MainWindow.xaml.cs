using System.Windows;
using System.Windows.Controls;
namespace ObuvApp;
public partial class MainWindow : Window
{
    private string role = "Гость";
    public MainWindow()
    {
        InitializeComponent();
        try
        {
            Database.CheckConnection();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось подключиться к SQL Server. Проверь имя сервера в Database.cs и сначала выполни SQL_ObuvDB.sql в SSMS.\n\n" + ex.Message,
                "Ошибка подключения", MessageBoxButton.OK, MessageBoxImage.Error);
            Application.Current.Shutdown();
            return;
        }
        SortBox.SelectedIndex = 0;
        LoginWindow login = new();
        if (login.ShowDialog() == true) role = login.UserRole;
        UserInfo.Text = "Пользователь: " + role;
        bool staff = role == "Менеджер" || role == "Администратор";
        bool admin = role == "Администратор";
        ToolsPanel.Visibility = staff ? Visibility.Visible : Visibility.Collapsed;
        AddProductButton.Visibility = EditProductButton.Visibility = DeleteProductButton.Visibility = admin ? Visibility.Visible : Visibility.Collapsed;
        OrdersButton.Visibility = role == "Менеджер" || admin ? Visibility.Visible : Visibility.Collapsed;
        AddOrderButton.Visibility = EditOrderButton.Visibility = DeleteOrderButton.Visibility = admin ? Visibility.Visible : Visibility.Collapsed;
        LoadProducts();
    }
    private void LoadProducts()
    {
        string search = (role == "Менеджер" || role == "Администратор") ? SearchBox.Text : "";
        string sort = (SortBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "По названию";
        ProductsGrid.ItemsSource = Database.GetProducts(search, sort);
    }
    private void LoadOrders() => OrdersGrid.ItemsSource = Database.GetOrders();
    private void ProductsButton_Click(object sender, RoutedEventArgs e) { ProductsPanel.Visibility=Visibility.Visible; OrdersPanel.Visibility=Visibility.Collapsed; LoadProducts(); }
    private void OrdersButton_Click(object sender, RoutedEventArgs e) { ProductsPanel.Visibility=Visibility.Collapsed; OrdersPanel.Visibility=Visibility.Visible; LoadOrders(); }
    private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) { if (IsLoaded) LoadProducts(); }
    private void SortBox_SelectionChanged(object sender, SelectionChangedEventArgs e) { if (IsLoaded) LoadProducts(); }
    private Product SelectedProduct => ProductsGrid.SelectedItem as Product;
    private Order SelectedOrder => OrdersGrid.SelectedItem as Order;
    private void AddProduct_Click(object sender, RoutedEventArgs e) { var w=new ProductWindow(); if(w.ShowDialog()==true){Database.SaveProduct(w.Result);LoadProducts();} }
    private void EditProduct_Click(object sender, RoutedEventArgs e) { if(SelectedProduct==null){MessageBox.Show("Выберите товар.");return;} var w=new ProductWindow(SelectedProduct); if(w.ShowDialog()==true){Database.SaveProduct(w.Result);LoadProducts();} }
    private void DeleteProduct_Click(object sender, RoutedEventArgs e) { if(SelectedProduct==null){MessageBox.Show("Выберите товар.");return;} if(MessageBox.Show("Удалить выбранный товар?","Подтверждение",MessageBoxButton.YesNo)==MessageBoxResult.Yes){Database.DeleteProduct(SelectedProduct.Id);LoadProducts();} }
    private void AddOrder_Click(object sender, RoutedEventArgs e) { var w=new OrderWindow(); if(w.ShowDialog()==true){Database.SaveOrder(w.Result);LoadOrders();} }
    private void EditOrder_Click(object sender, RoutedEventArgs e) { if(SelectedOrder==null){MessageBox.Show("Выберите заказ.");return;} var w=new OrderWindow(SelectedOrder); if(w.ShowDialog()==true){Database.SaveOrder(w.Result);LoadOrders();} }
    private void DeleteOrder_Click(object sender, RoutedEventArgs e) { if(SelectedOrder==null){MessageBox.Show("Выберите заказ.");return;} if(MessageBox.Show("Удалить выбранный заказ?","Подтверждение",MessageBoxButton.YesNo)==MessageBoxResult.Yes){Database.DeleteOrder(SelectedOrder.Id);LoadOrders();} }
    private void Logout_Click(object sender, RoutedEventArgs e) { Close(); }
}
