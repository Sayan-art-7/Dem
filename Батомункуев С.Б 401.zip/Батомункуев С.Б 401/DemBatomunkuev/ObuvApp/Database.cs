using Microsoft.Data.SqlClient;

namespace ObuvApp;

public static class Database
{
    private const string ConnectionString =
        @"Server=BSB;Database=ObuvDB;Integrated Security=True;TrustServerCertificate=True;";

    public static void CheckConnection()
    {
        using var connection = new SqlConnection(ConnectionString);
        connection.Open();
    }

    public static List<Product> GetProducts(string search = "", string sort = "Name")
    {
        using var connection = new SqlConnection(ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();

        string order = sort == "Цена ↑" ? "Price ASC" : sort == "Цена ↓" ? "Price DESC" : "Name ASC";
        command.CommandText = @"SELECT Id, Name, Article, Category, Size, Price, Discount, Stock, Manufacturer
                                FROM Products
                                WHERE Name LIKE @search OR Article LIKE @search OR Category LIKE @search
                                ORDER BY " + order;
        command.Parameters.AddWithValue("@search", "%" + search + "%");

        using var reader = command.ExecuteReader();
        var products = new List<Product>();
        while (reader.Read())
        {
            products.Add(new Product
            {
                Id = reader.GetInt32(0),
                Name = reader.GetString(1),
                Article = reader.GetString(2),
                Category = reader.GetString(3),
                Size = reader.GetString(4),
                Price = reader.GetDecimal(5),
                Discount = reader.GetInt32(6),
                Stock = reader.GetInt32(7),
                Manufacturer = reader.GetString(8)
            });
        }
        return products;
    }

    public static void SaveProduct(Product product)
    {
        using var connection = new SqlConnection(ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();

        if (product.Id == 0)
        {
            command.CommandText = @"INSERT INTO Products(Name, Article, Category, Size, Price, Discount, Stock, Manufacturer)
                                    VALUES(@name, @article, @category, @size, @price, @discount, @stock, @manufacturer)";
        }
        else
        {
            command.CommandText = @"UPDATE Products SET Name=@name, Article=@article, Category=@category, Size=@size,
                                    Price=@price, Discount=@discount, Stock=@stock, Manufacturer=@manufacturer WHERE Id=@id";
            command.Parameters.AddWithValue("@id", product.Id);
        }

        AddProductParameters(command, product);
        command.ExecuteNonQuery();
    }

    private static void AddProductParameters(SqlCommand command, Product product)
    {
        command.Parameters.AddWithValue("@name", product.Name);
        command.Parameters.AddWithValue("@article", product.Article);
        command.Parameters.AddWithValue("@category", product.Category ?? "");
        command.Parameters.AddWithValue("@size", product.Size ?? "");
        command.Parameters.AddWithValue("@price", product.Price);
        command.Parameters.AddWithValue("@discount", product.Discount);
        command.Parameters.AddWithValue("@stock", product.Stock);
        command.Parameters.AddWithValue("@manufacturer", product.Manufacturer ?? "");
    }

    public static void DeleteProduct(int id)
    {
        Execute("DELETE FROM Products WHERE Id=@id", id);
    }

    public static List<Order> GetOrders()
    {
        using var connection = new SqlConnection(ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT Id, Customer, ProductName, Quantity, Total, Status, OrderDate FROM Orders ORDER BY Id DESC";

        using var reader = command.ExecuteReader();
        var orders = new List<Order>();
        while (reader.Read())
        {
            orders.Add(new Order
            {
                Id = reader.GetInt32(0),
                Customer = reader.GetString(1),
                ProductName = reader.GetString(2),
                Quantity = reader.GetInt32(3),
                Total = reader.GetDecimal(4),
                Status = reader.GetString(5),
                OrderDate = reader.GetString(6)
            });
        }
        return orders;
    }

    public static void SaveOrder(Order order)
    {
        using var connection = new SqlConnection(ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();

        if (order.Id == 0)
        {
            command.CommandText = @"INSERT INTO Orders(Customer, ProductName, Quantity, Total, Status, OrderDate)
                                    VALUES(@customer, @product, @quantity, @total, @status, @date)";
        }
        else
        {
            command.CommandText = @"UPDATE Orders SET Customer=@customer, ProductName=@product, Quantity=@quantity,
                                    Total=@total, Status=@status, OrderDate=@date WHERE Id=@id";
            command.Parameters.AddWithValue("@id", order.Id);
        }

        command.Parameters.AddWithValue("@customer", order.Customer);
        command.Parameters.AddWithValue("@product", order.ProductName);
        command.Parameters.AddWithValue("@quantity", order.Quantity);
        command.Parameters.AddWithValue("@total", order.Total);
        command.Parameters.AddWithValue("@status", order.Status);
        command.Parameters.AddWithValue("@date", order.OrderDate);
        command.ExecuteNonQuery();
    }

    public static void DeleteOrder(int id)
    {
        Execute("DELETE FROM Orders WHERE Id=@id", id);
    }

    private static void Execute(string sql, int id)
    {
        using var connection = new SqlConnection(ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText = sql;
        command.Parameters.AddWithValue("@id", id);
        command.ExecuteNonQuery();
    }

    public static string Login(string login, string password)
    {
        using var connection = new SqlConnection(ConnectionString);
        connection.Open();
        using var command = connection.CreateCommand();
        command.CommandText = "SELECT Role FROM Users WHERE Login=@login AND Password=@password";
        command.Parameters.AddWithValue("@login", login);
        command.Parameters.AddWithValue("@password", password);
        return command.ExecuteScalar()?.ToString();
    }
}
