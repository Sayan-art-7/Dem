namespace ObuvApp;
public class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Article { get; set; }
    public string Category { get; set; }
    public string Size { get; set; }
    public decimal Price { get; set; }
    public int Discount { get; set; }
    public int Stock { get; set; }
    public string Manufacturer { get; set; }
    public decimal FinalPrice => Price * (100 - Discount) / 100;
    public bool IsHighDiscount => Discount > 15;
}
public class Order
{
    public int Id { get; set; }
    public string Customer { get; set; }
    public string ProductName { get; set; }
    public int Quantity { get; set; }
    public decimal Total { get; set; }
    public string Status { get; set; }
    public string OrderDate { get; set; }
}
