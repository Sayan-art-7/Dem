using System.Windows;
namespace ObuvApp;
public partial class ProductWindow : Window
{
    public Product Result { get; private set; } = new();
    public ProductWindow(Product p=null)
    {
        InitializeComponent();
        if(p!=null){Result.Id=p.Id;NameBox.Text=p.Name;ArticleBox.Text=p.Article;CategoryBox.Text=p.Category;SizeBox.Text=p.Size;PriceBox.Text=p.Price.ToString();DiscountBox.Text=p.Discount.ToString();StockBox.Text=p.Stock.ToString();ManufacturerBox.Text=p.Manufacturer;}
    }
    private void Save_Click(object sender,RoutedEventArgs e)
    {
        if(string.IsNullOrWhiteSpace(NameBox.Text)||string.IsNullOrWhiteSpace(ArticleBox.Text)||
           !decimal.TryParse(PriceBox.Text,out decimal price)||!int.TryParse(DiscountBox.Text,out int discount)||
           !int.TryParse(StockBox.Text,out int stock)||price<0||discount<0||discount>100||stock<0)
        {MessageBox.Show("Проверьте название, артикул, цену, скидку и остаток.");return;}
        Result.Name=NameBox.Text.Trim();Result.Article=ArticleBox.Text.Trim();Result.Category=CategoryBox.Text.Trim();
        Result.Size=SizeBox.Text.Trim();Result.Price=price;Result.Discount=discount;Result.Stock=stock;Result.Manufacturer=ManufacturerBox.Text.Trim();
        DialogResult=true;
    }
}
