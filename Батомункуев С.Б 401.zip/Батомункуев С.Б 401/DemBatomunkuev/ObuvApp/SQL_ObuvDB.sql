/* Запусти весь скрипт в SQL Server Management Studio (SSMS). */
IF DB_ID(N'ObuvDB') IS NULL
    CREATE DATABASE ObuvDB;
GO

USE ObuvDB;
GO

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users
    (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Login NVARCHAR(50) NOT NULL UNIQUE,
        Password NVARCHAR(100) NOT NULL,
        Role NVARCHAR(30) NOT NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products
    (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(150) NOT NULL,
        Article NVARCHAR(50) NOT NULL,
        Category NVARCHAR(80) NOT NULL,
        Size NVARCHAR(20) NOT NULL,
        Price DECIMAL(10,2) NOT NULL,
        Discount INT NOT NULL DEFAULT 0,
        Stock INT NOT NULL DEFAULT 0,
        Manufacturer NVARCHAR(100) NOT NULL
    );
END;
GO

IF OBJECT_ID(N'dbo.Orders', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Orders
    (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Customer NVARCHAR(150) NOT NULL,
        ProductName NVARCHAR(150) NOT NULL,
        Quantity INT NOT NULL,
        Total DECIMAL(10,2) NOT NULL,
        Status NVARCHAR(50) NOT NULL,
        OrderDate NVARCHAR(20) NOT NULL
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Users)
BEGIN
    INSERT INTO dbo.Users(Login, Password, Role) VALUES
    (N'admin', N'admin123', N'Администратор'),
    (N'manager', N'manager123', N'Менеджер'),
    (N'client', N'client123', N'Клиент');
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Products)
BEGIN
    INSERT INTO dbo.Products(Name, Article, Category, Size, Price, Discount, Stock, Manufacturer) VALUES
    (N'Кроссовки спортивные', N'A001', N'Кроссовки', N'42', 5500, 10, 12, N'Россия'),
    (N'Ботинки зимние', N'B002', N'Ботинки', N'43', 8200, 20, 7, N'Китай'),
    (N'Туфли классические', N'C003', N'Туфли', N'41', 6300, 5, 9, N'Россия'),
    (N'Сандалии', N'D004', N'Сандалии', N'40', 2900, 0, 15, N'Беларусь'),
    (N'Кеды повседневные', N'E005', N'Кеды', N'42', 4100, 18, 5, N'Китай');
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Orders)
BEGIN
    INSERT INTO dbo.Orders(Customer, ProductName, Quantity, Total, Status, OrderDate) VALUES
    (N'Иванов И.И.', N'Кроссовки спортивные', 1, 4950, N'Новый', N'24.11.2026'),
    (N'Петров П.П.', N'Ботинки зимние', 2, 13120, N'В обработке', N'23.11.2026');
END;
GO

SELECT * FROM dbo.Users;
SELECT * FROM dbo.Products;
SELECT * FROM dbo.Orders;
