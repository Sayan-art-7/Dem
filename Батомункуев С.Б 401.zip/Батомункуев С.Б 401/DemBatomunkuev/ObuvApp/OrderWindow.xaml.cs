using System.Windows;
using System.Windows.Controls;
namespace ObuvApp;
public partial class OrderWindow : Window
{
    public Order Result { get; private set; } = new();
    public OrderWindow(Order o=null)
    {
        InitializeComponent();
        if(o==null) DateBox.Text=DateTime.Now.ToString("dd.MM.yyyy");
        else {Result.Id=o.Id;CustomerBox.Text=o.Customer;ProductBox.Text=o.ProductName;QuantityBox.Text=o.Quantity.ToString();TotalBox.Text=o.Total.ToString();DateBox.Text=o.OrderDate;
            foreach(ComboBoxItem item in StatusBox.Items) if(item.Content.ToString()==o.Status) StatusBox.SelectedItem=item;}
        if(StatusBox.SelectedIndex<0) StatusBox.SelectedIndex=0;
    }
    private void Save_Click(object sender,RoutedEventArgs e)
    {
        if(string.IsNullOrWhiteSpace(CustomerBox.Text)||string.IsNullOrWhiteSpace(ProductBox.Text)||
           !int.TryParse(QuantityBox.Text,out int q)||q<1||!decimal.TryParse(TotalBox.Text,out decimal total)||total<0||string.IsNullOrWhiteSpace(DateBox.Text))
        {MessageBox.Show("Проверьте покупателя, товар, количество, сумму и дату.");return;}
        Result.Customer=CustomerBox.Text.Trim();Result.ProductName=ProductBox.Text.Trim();Result.Quantity=q;Result.Total=total;
        Result.Status=(StatusBox.SelectedItem as ComboBoxItem)?.Content.ToString()??"Новый";Result.OrderDate=DateBox.Text.Trim();DialogResult=true;
    }
}
